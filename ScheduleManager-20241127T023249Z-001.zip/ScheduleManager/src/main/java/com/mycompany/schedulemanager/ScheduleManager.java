/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.schedulemanager;

/**
 *
 * @author punthe2
 */
public class ScheduleManager {

    public static void main(String[] args) {
        new ScheduleManagerFrame().setVisible(true);
    }
}
